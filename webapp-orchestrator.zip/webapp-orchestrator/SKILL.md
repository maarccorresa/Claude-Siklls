---
name: webapp-orchestrator
description: Analiza una aplicación web a partir de su código, crea un plan detallado por fases y lo ejecuta con un equipo jerárquico de subagentes (un vigía que controla el uso de tokens del plan, y especialistas en desarrollo, estilos/UI, QA y accesibilidad/SEO/rendimiento) dirigido por ti como director, ajustando el trabajo al uso que queda. Úsala siempre que el usuario quiera mejorar, rediseñar, arreglar, ampliar o reconstruir una web o app web y el trabajo toque varias áreas o varios pasos — por ejemplo "analiza mi web y mejórala", "revisa mi proyecto de React y haz un plan", "quiero rehacer esta página", "mi app necesita nuevas features y un lavado de cara", "reconstruye algo como esta web" — aunque no mencione planes, fases, agentes ni tokens. No la uses para un cambio puntual y pequeño (un solo bug, un color) ni para ingeniería inversa de binarios o paquetes.
---

# Web App Orchestrator

Esta skill convierte una petición amplia sobre una aplicación web en trabajo ordenado, hecho por un equipo jerárquico que cuida el presupuesto de tokens:

```
                 DIRECTOR (tú, la conversación principal)
                 decide qué se hace con el uso que queda y reparte el trabajo
                /                         \
        VIGÍA                          ESPECIALISTAS
  solo informa del uso del plan    análisis · desarrollo · estilos · qa · calidad
  y de cuándo se reinicia          cada uno con su parte única del trabajo
```

**Tú eres el director.** El director tiene que ser la conversación principal porque es la única que puede lanzar subagentes. Los subagentes no lanzan otros subagentes, así que toda la delegación pasa por ti. Tu trabajo es decidir, repartir y verificar, no hacer el trabajo de los especialistas. Haz tú mismo solo lo trivial (menos de unas pocas líneas), porque lanzar un agente para eso cuesta más que hacerlo.

Flujo:

0. Identificar el objetivo y el modo.
1. Consultar al vigía → presupuesto inicial.
2. Análisis del código, repartido por áreas.
3. Plan por fases, dimensionado al presupuesto.
4. Aprobación del usuario.
5. Ejecución fase a fase, consultando al vigía antes de cada fase.
6. Cierre: QA visual final (aquí, y solo aquí, se hacen capturas) e informe.

Toda la documentación de trabajo vive en `.orquesta/`, en la raíz del proyecto.

---

## Principios de ahorro (se aplican a todo el equipo)

Lo que más tokens consume no es lo que escribe un agente, sino lo que **lee**: archivos, páginas, imágenes y logs. Por eso:

- **Cada agente recibe solo su parte.** Nunca el análisis entero ni el plan entero: solo su archivo de análisis, su tarea, y los archivos y líneas exactos que le tocan. Así no explora el proyecto por su cuenta.
- **Leer con precisión.** Primero buscar con Grep o Glob y después leer fragmentos (`offset`/`limit`), no archivos enteros. No releer lo que ya se ha leído.
- **Tests dirigidos.** Cada agente ejecuta solo los tests relacionados con su tarea. La batería completa se ejecuta una vez, en el cierre.
- **Logs mínimos.** En los informes, solo las líneas relevantes del error, nunca el log completo.
- **Sin capturas hasta el final.** El análisis lee código, que contiene la misma información que una captura y cuesta mucho menos. Las capturas de pantalla se reservan para la verificación visual del cierre.
- **Comunicación caveman.** Todos los subagentes cargan la skill `caveman:caveman` y la usan en sus informes y mensajes. **No** la usan en el código, en los textos de la interfaz, en los tests ni en los documentos de `.orquesta/`, que deben ser correctos y legibles. Tus mensajes al usuario siguen en estilo normal, salvo que él active caveman.
- **Agentes nuevos y ligeros.** Lanza los subagentes en modo "fresh" con un encargo corto, nunca como fork de la conversación. Para corregir una tarea, escribe al mismo agente (`SendMessage`) en vez de lanzar uno nuevo, porque ya tiene el contexto.
- **Unir tareas pequeñas.** Varias tareas pequeñas del mismo rol y de la misma zona van en un solo encargo.

Los encargos de cada rol, con estos principios ya incluidos, están en `references/briefs-agentes.md`.

---

## El vigía y la política de presupuesto

El **vigía** es un subagente mínimo (modelo `haiku`, esfuerzo `low`) cuya única tarea es llamar a `mcp__ccd_session_mgmt__get_usage` y devolver el uso del plan en una línea. El encargo exacto está en `references/briefs-agentes.md`. Si en su entorno no tiene esa herramienta, haz tú la llamada directamente: el dato importa más que quién lo recoja.

**Cuándo consultarlo:** antes de planificar, antes de cada fase y entre tareas si una fase es larga (más de 3 tareas).

Con su informe, el director clasifica el presupuesto usando el **peor** de los dos indicadores:

| Nivel | Límite de 5 h | Límite semanal | Qué hace el director |
|---|---|---|---|
| 🟢 **Verde** | < 60 % | < 75 % | Plan completo. Paralelismo permitido. Modelos según la tabla de roles. |
| 🟡 **Ámbar** | 60–85 % | 75–90 % | Solo tareas de gravedad alta y media. Sin paralelismo. Todos los roles bajan un escalón de modelo. La fase de calidad se reduce a lo crítico. |
| 🔴 **Rojo** | > 85 % | > 90 % | Termina la tarea en curso y no empieza ninguna más. Guarda el estado en `plan.md` y avisa al usuario de la hora de reinicio (`resetsAt`, en su hora local) para continuar entonces. |

Casos especiales:
- `status: "not_applicable"`: no hay límites de plan (clave de API, etc.). Trabaja en verde.
- `status: "unavailable"`: no se pudo leer el uso. Trabaja en ámbar y vuelve a consultar en la siguiente fase.
- Si el límite de 5 h está en rojo pero se reinicia en menos de unos 30 minutos, díselo al usuario y ofrécele esperar en lugar de recortar el plan.

**Modelos por rol** (en verde; en ámbar, baja un escalón: opus→sonnet→haiku):

| Rol | Modelo | Esfuerzo |
|---|---|---|
| vigía | haiku | low |
| análisis | haiku | low |
| qa | haiku | low |
| calidad | haiku | medium |
| estilos | sonnet | medium |
| desarrollo | sonnet (opus solo si la tarea es compleja y estás en verde) | medium |

Pasa siempre `model` y `effort` al lanzar cada subagente: esta skill te lo pide expresamente.

---

## Fase 0 — Objetivo y modo

Aclara lo siguiente. Si algo no se deduce, pregunta una sola vez, todo junto:

- **Código fuente**: ¿dónde está?
- **URL** de la app (local, staging o producción). Solo hará falta en el cierre, o en el análisis si no hay código.
- **Qué quiere conseguir** el usuario, en sus palabras.

| Situación | Modo |
|---|---|
| Hay código del proyecto | **Mejorar**: los especialistas modifican ese código. |
| Solo hay una URL | **Reconstruir**: se crea un proyecto nuevo que reproduce la funcionalidad y la estructura. |

En modo Reconstruir el "código" que se analiza es el HTML/DOM de la página, leído como texto (`get_page_text`, o `read_page` limitado a una zona). Sigue sin haber capturas. Si la app es de terceros, reproduce la funcionalidad y los patrones de layout, pero no copies logotipos, marcas, textos ni imágenes propietarias: usa contenido de ejemplo e identidad visual propia, y avisa de ello en el plan.

Si el usuario dice "mi app" sin más pistas, pregunta cuál.

---

## Fase 1 — Presupuesto inicial

Lanza al vigía y clasifica el nivel. Si ya estás en rojo, no empieces: informa al usuario de la hora de reinicio.

---

## Fase 2 — Análisis por áreas (solo código)

1. **Reconocimiento rápido (lo haces tú, y es barato):** lee el `package.json` o equivalente, el árbol de carpetas a 2 niveles y cómo se arranca y se testea el proyecto. Con eso escribe `.orquesta/resumen.md` (stack, comandos y carpetas clave; máximo unas 15 líneas). Este resumen es lo único que comparten todos los agentes.
2. **Analistas por área**, en paralelo si estás en verde. Cada uno lee solo su zona del código y escribe solo su archivo:

| Analista | Lee | Escribe |
|---|---|---|
| desarrollo | rutas, componentes, estado, API, manejo de errores | `.orquesta/analisis/desarrollo.md` |
| estilos | hojas de estilo, tokens o variables, clases en componentes, breakpoints | `.orquesta/analisis/estilos.md` |
| calidad | marcado semántico, alt y labels, `<head>`/meta, imágenes y recursos pesados | `.orquesta/analisis/calidad.md` |

   En ámbar, junta los tres en un solo analista que escribe los tres archivos. En proyectos muy pequeños (pocos archivos) haz el análisis tú mismo.
3. **QA** no necesita analista: tú escribes `.orquesta/analisis/qa.md` con los comandos de test, los tests existentes y los flujos clave que se verificarán en el cierre.

Cada archivo de análisis separa **Observado** (con `archivo:línea`), **Inferido** y **Desconocido**, y termina con una lista de problemas con gravedad alta, media o baja. La plantilla está en `references/plantillas.md`. Esa separación evita que un especialista "arregle" algo a partir de una suposición.

---

## Fase 3 — Plan por fases

Escribe `.orquesta/plan.md` (plantilla en `references/plantillas.md`) a partir de la petición del usuario y de los problemas encontrados.

**Roles:**

| Rol | Se encarga de | No toca |
|---|---|---|
| desarrollo | lógica, componentes, rutas, estado, APIs, bugs funcionales | diseño visual más allá de lo mínimo |
| estilos | CSS, diseño, responsive, tipografía, color, tokens | lógica ni llamadas a API |
| qa | tests y verificación (visual solo en el cierre) | código de producción (informa de los fallos) |
| calidad | accesibilidad WCAG AA, SEO y rendimiento | rediseños ni features nuevas |

**Reglas:**
- Cada tarea tiene **un solo rol**, una **zona exclusiva** (archivos o rangos de líneas), sus dependencias, un **coste estimado** (S/M/L) y unos **criterios de aceptación comprobables**.
- **Orden típico:** fundamentos (build roto, estructura, tokens) → funcionalidad → interfaz → calidad → cierre con QA. Omite las fases que no hagan falta.
- **Paralelismo** solo en verde, y solo entre tareas sin archivos en común.
- **Dimensiona al presupuesto:** si el plan completo no cabe en el nivel actual, ordénalo por prioridad y marca qué queda para después del reinicio.
- Relaciona cada objetivo del usuario con las tareas que lo cubren.

---

## Fase 4 — Aprobación

Presenta al usuario un resumen breve: el presupuesto (nivel, % usado y hora de reinicio), los objetivos, las fases con una línea por tarea (rol, coste y modelo), qué va en paralelo y los riesgos. Indica que el plan completo está en `.orquesta/plan.md`.

**Espera su aprobación antes de ejecutar.** Si pide cambios, actualiza el plan y vuelve a presentarlo.

---

## Fase 5 — Ejecución

Para cada fase:

1. **Vigía** → reclasifica el nivel y ajusta (modelos, paralelismo, recortes) según la política. Si cambia de nivel, díselo al usuario en una línea.
2. **Lanza a los especialistas** con su encargo de `references/briefs-agentes.md`, rellenado solo con lo suyo: su tarea, su zona exclusiva, la ruta de **su** archivo de análisis y la de `resumen.md`. Las tareas paralelas se lanzan todas en el mismo mensaje.
3. **Recoge los informes** y actualiza `plan.md` (estado y una línea de notas).
4. **Verifica sin navegador:** la build y los tests de lo que ha cambiado. Un informe es la versión del agente, no una prueba.
5. **Fallos:** si son pequeños, envía un mensaje (`SendMessage`) al mismo agente con la corrección. Si alteran el plan, para y consulta al usuario.

Si no hay herramienta de subagentes, haz cada tarea tú mismo siguiendo el encargo de su rol.

---

## Fase 6 — Cierre

1. **Vigía.** Si estás en rojo, deja el QA visual para después del reinicio y díselo al usuario.
2. **QA final** (el único momento con navegador y capturas): build y batería completa de tests, flujos clave a escritorio y a móvil con capturas a escala 0.5, consola y red. El encargo está en `references/briefs-agentes.md` ("qa-cierre").
3. Si QA encuentra fallos, crea tareas de corrección (paso 5) y repite solo la verificación de lo afectado.
4. Escribe `.orquesta/informe-final.md` y resume al usuario: lo conseguido, lo pendiente, lo no verificado y el uso final del plan. Si hay git, ofrece hacer commit o abrir un PR, pero no lo hagas sin que te lo pida.
