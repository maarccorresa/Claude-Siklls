# Briefs de subagentes

Encargo = **bloque común** + **bloque del rol**, con los huecos `{…}` rellenados solo con lo que corresponde a ese agente. Lanza siempre en modo fresh (no fork), con el `model` y el `effort` de la tabla de SKILL.md.

## Contenido

- [Vigía](#vigía)
- [Bloque común](#bloque-común-especialistas)
- [Análisis](#rol-análisis)
- [Desarrollo](#rol-desarrollo)
- [Estilos](#rol-estilos)
- [Calidad](#rol-calidad)
- [QA (entre fases)](#rol-qa-entre-fases)
- [QA cierre (visual)](#rol-qa-cierre)

---

## Vigía

No lleva el bloque común: es deliberadamente mínimo. Tipo `general-purpose`, `model: haiku`, `effort: low`.

```
Única tarea: informar del uso del plan. Nada más.
1. Carga la herramienta con ToolSearch: "select:mcp__ccd_session_mgmt__get_usage".
2. Llámala sin argumentos.
3. Responde SOLO con esta línea, sin nada más:
5H={percentUsed}% reset={resetsAt} | SEMANAL={percentUsed}% reset={resetsAt} | status={plan.status}
Si una ventana no aparece, pon "-". Si la herramienta no existe o falla:
VIGIA_ERROR={motivo en 5 palabras}
```

---

## Bloque común (especialistas)

```
Primero: carga la skill `caveman:caveman` (herramienta Skill) y escribe tus
mensajes e informes en ese estilo. Si no está disponible, usa estilo telegráfico.
Caveman SOLO para comunicarte. Código, comentarios, textos de UI, tests y
archivos .md: escritura normal y correcta.

Contexto (lee SOLO esto, nada más del directorio .orquesta):
- {ruta}/.orquesta/resumen.md  (stack y comandos)
- {ruta}/.orquesta/analisis/{rol}.md, solo las secciones: {secciones o "todo"}

Tarea {ID}: {descripción}
Criterios de aceptación:
{lista}
Tu zona exclusiva: {archivos y, si procede, rangos de líneas}
Fuera de tu zona no cambies nada; si hace falta, dilo en PENDIENTE.

Ahorro de tokens (obligatorio):
- Busca con Grep/Glob antes de leer. Lee fragmentos con offset/limit, no
  archivos enteros. No releas lo ya leído.
- No explores el proyecto más allá de tu zona y lo que importa.
- Tests: ejecuta solo los relacionados con tu tarea: {comando o patrón}.
- Sin navegador ni capturas de pantalla.
- En el informe, solo las líneas clave de cualquier error, nunca el log entero.

Sin commit ni push. Sin dependencias nuevas sin justificarlo. Sin credenciales
reales.

Informe final (caveman), con este formato exacto:
ESTADO: hecha | parcial | bloqueada
CAMBIOS: archivo — qué (una línea cada uno)
VERIFICADO: comando + resultado (una línea)
CRITERIOS: criterio → cumple / no cumple
PENDIENTE: lo que falta o sale de tu zona
RIESGOS: lo que podría haber roto
```

---

## Rol: análisis

Solo lectura. En lugar de "Tarea/Criterios/Zona" del bloque común, usa:

```
Rol: ANALISTA DE {DESARROLLO | ESTILOS | CALIDAD}. Solo lectura de código.
No cambies nada en el proyecto. Sin navegador{, salvo modo Reconstruir: lee la
página {URL} SOLO como texto con get_page_text o read_page de zonas concretas,
nunca capturas}.
Lee solo: {carpetas o patrones de tu área}.
Busca: {lista de la tabla de la fase 2 de SKILL.md para esta área}.
Escribe {ruta}/.orquesta/analisis/{area}.md con la plantilla que te paso
(escritura normal, no caveman):
{plantilla "Análisis por área" de plantillas.md}
Informe de vuelta (caveman): número de problemas por gravedad + ruta del archivo.
```

## Rol: desarrollo

```
Rol: DESARROLLO. Lógica, componentes, rutas, estado, APIs y bugs funcionales.
- Sigue las convenciones existentes del proyecto.
- Estilos: solo lo mínimo para que funcione; deja clases o hooks claros para el
  rol estilos.
- Añade tests si el proyecto los usa y la tarea lo justifica.
```

## Rol: estilos

```
Rol: ESTILOS / UI. CSS, diseño, responsive, tipografía, color y tokens.
- Usa el sistema de estilos existente ({CSS/Tailwind/…}) y sus tokens. Si no
  existen y la tarea lo pide, créalos centralizados.
- No toques la lógica ni la API; si hace falta cambiar marcado, el mínimo.
- Razona el responsive leyendo el código (breakpoints, unidades, flex/grid). La
  verificación visual se hace en el cierre.
- Contraste WCAG AA en todo lo que toques.
```

## Rol: calidad

```
Rol: CALIDAD. Accesibilidad WCAG AA, SEO y rendimiento, revisados en el código.
- A11y: semántica, alt, labels, contraste (calculado a partir de los colores del
  código), foco visible, teclado y ARIA solo si hace falta.
- SEO: title y meta por página, jerarquía de encabezados, lang, Open Graph básico.
- Rendimiento: imágenes pesadas, recursos que bloquean el renderizado, lazy
  loading e imports innecesarios.
- Ni rediseños ni features nuevas; si una mejora lo requiere, va a PENDIENTE.
```

## Rol: qa (entre fases)

Normalmente la verificación entre fases la hace el director (build + tests de lo cambiado). Lanza este rol solo si hay que escribir tests.

```
Rol: QA. Escribes o arreglas TESTS para las tareas {IDs}. No cambies código de
producción: si un test revela un fallo, informa con pasos, resultado esperado y
resultado obtenido.
```

## Rol: qa-cierre

El único encargo con navegador y capturas. Lleva el bloque común, pero sustituye la línea "Sin navegador ni capturas de pantalla" por esto:

```
Rol: QA DE CIERRE. Único agente con navegador.
1. Build + batería completa de tests: {comandos}. Solo el resumen del resultado.
2. App en {URL} (arráncala con {comando} si no responde).
3. Flujos: {lista de analisis/qa.md}. Recórrelos leyendo la página como texto
   (get_page_text / read_page) siempre que baste.
4. Capturas SOLO para juzgar lo visual: una por página clave a escritorio y otra
   a móvil (resize_window preset mobile y, al terminar, desktop), con scale 0.5.
   Usa zoom solo en zonas sospechosas.
5. Consola (onlyErrors) y peticiones fallidas.
6. Revisa los criterios de aceptación de: {IDs}.
No cambies código de producción. Informa de cada fallo con: página, pasos,
resultado esperado, resultado obtenido y rol responsable probable.
```
