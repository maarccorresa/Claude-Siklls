# Plantillas de `.orquesta/`

Estos documentos los lee el usuario: escríbelos en estilo normal, no en caveman. Que sean breves, porque cada línea la vuelve a leer algún agente.

```
.orquesta/
├── resumen.md          # compartido por todos: stack, comandos y carpetas (≤15 líneas)
├── analisis/
│   ├── desarrollo.md   # solo lo lee el rol desarrollo
│   ├── estilos.md      # solo lo lee el rol estilos
│   ├── calidad.md      # solo lo lee el rol calidad
│   └── qa.md           # tests y flujos clave; lo lee QA
├── plan.md             # lo lee el director (y el usuario)
└── informe-final.md
```

## `resumen.md`

```markdown
# {app} · Modo {Mejorar | Reconstruir}
- Stack: {framework, lenguaje, estilos, tests}
- Arrancar: `{comando}` → {URL}
- Build: `{comando}` · Tests: `{comando}` (un archivo: `{patrón}`)
- Carpetas: {ruta} = {qué hay}, …
```

## Análisis por área (`analisis/{area}.md`)

```markdown
# Análisis {área}
## Observado
- {hecho} — `archivo:línea`
## Inferido
- {conclusión} — basada en {…}
## Desconocido
- {pregunta}
## Problemas
| # | Problema | Gravedad | Dónde |
|---|---|---|---|
```

## `analisis/qa.md`

```markdown
# QA
- Tests existentes: {dónde y cuántos, aproximadamente}
- Comandos: {build, tests completos, test de un archivo}
## Flujos clave a verificar en el cierre
1. {flujo}: {pasos} → {resultado esperado}
```

## `plan.md`

```markdown
# Plan: {objetivo}
Estado: {pendiente de aprobación | aprobado | en curso | pausado hasta {hora} | terminado}
Presupuesto: {🟢/🟡/🔴} · 5 h {x} % (reinicio {hora}) · semanal {y} % (reinicio {fecha})

## Objetivos → tareas
| Objetivo | Tareas |
|---|---|

## Identidad (solo modo Reconstruir de una app ajena)
- Nombre: {nombre propio} · Paleta: {hex…} · Tipografías: {…} · Tono: {…}
- Provisional: {sí/no; si no la ha aportado el usuario, sí}
- No se copia de la original: nombre ({…}), colores ({hex…}), tipografías, logo,
  imágenes, textos ni composición exacta.

## Fase {N}: {nombre} · paralelo: {sí/no}
| ID | Rol | Tarea | Zona | Coste | Modelo | Depende | Estado |
|---|---|---|---|---|---|---|---|
Criterios:
- T{n}: {criterio comprobable}; {…}

## Para después del reinicio
- {tareas recortadas por presupuesto}

## Registro
- {hora} {nivel} — {decisión del director o resultado de una tarea, en una línea}
```

## `informe-final.md`

```markdown
# Informe final: {objetivo}
## Resultado
{2-4 líneas}
## Por fase
- Fase {N} · T{n} ({rol}): {qué} — {cómo se verificó}
## QA de cierre
- Build/tests: {resultado}
- Visual: {páginas revisadas, escritorio/móvil, problemas}
## Pendiente / no verificado
- {…}
## Uso del plan
- Inicio {x} % → fin {y} % (5 h) · semanal {a} % → {b} %
```
